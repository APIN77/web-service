<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to the ARSTN Drag Race </h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>    
        <a href="login.php" class="btn">Login</a>    
    </nav>

    <div class="content">
        <img src="derag.png" alt="" >
    </div>

    <footer>
        <p>&copy; 2024 ARSTN Drag Race . All Rights Reserved.</p>
    </footer>
</body>
</html>
