<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to the ARSTN Drag Race </h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>        
    </nav>

    <?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM users WHERE user_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);
    $user = $stmt->fetch();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password_hash = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password
        $team_name = $_POST['team_name'];

        $query = "UPDATE users SET username = ?, password_hash = ?, team_name = ? WHERE user_id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$username, $password_hash, $team_name, $id]);

        header('Location: users.php');
    }
} else {
    echo "User ID not specified.";
    exit;
}

?>

<h1>Edit User</h1>
<form method="POST">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password" value="<?= htmlspecialchars($user['password_hash']) ?>" required>

    <label for="team_name">Nama Team:</label>
    <input type="team_name" id="team_name" name="team_name" value="<?= htmlspecialchars($user['team_name']) ?>" required>

    <button type="submit">Update</button>
</form>


    <footer>
        <p>&copy; 2024 ARSTN Drag Race . All Rights Reserved.</p>
    </footer>
</body>
</html>
