<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category_id = $_POST['category_id'];
    $race_type = $_POST['race_type'];
    $location = $_POST['location'];
    $date = $_POST['date'];

    $query = "INSERT INTO races (category_id, race_type, location, date) VALUES (?, ?, ?, ?)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$category_id, $race_type, $location, $date]);

    header('Location: races.php');
}

?>

<h1>Create New Race</h1>
<form method="POST">
    <label for="category_id">Category ID:</label>
    <input type="text" id="category_id" name="category_id" required>
    
    <label for="race_type">Race Type:</label>
    <input type="text" id="race_type" name="race_type" required>

    <label for="location">Location:</label>
    <input type="text" id="location" name="location">
    
    <label for="date">Date:</label>
    <input type="date" id="date" name="date">
    
    <button type="submit">Submit</button>
</form>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to the ARSTN Drag Race </h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>        
    </nav>

    <?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category_id = $_POST['category_id'];
    $race_type = $_POST['race_type'];
    $location = $_POST['location'];
    $date = $_POST['date'];

    $query = "INSERT INTO races (category_id, race_type, location, date) VALUES (?, ?, ?, ?)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$category_id, $race_type, $location, $date]);

    header('Location: races.php');
}

?>

<h1>Create New Race</h1>
<form method="POST">
    <label for="category_id">Category ID:</label>
    <input type="text" id="category_id" name="category_id" required>
    
    <label for="race_type">Race Type:</label>
    <input type="text" id="race_type" name="race_type" required>

    <label for="location">Location:</label>
    <input type="text" id="location" name="location">
    
    <label for="date">Date:</label>
    <input type="date" id="date" name="date">
    
    <button type="submit">Submit</button>
</form>


    <footer>
        <p>&copy; 2024 ARSTN Drag Race . All Rights Reserved.</p>
    </footer>
</body>
</html>
