<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to the ARSTN Drag Race </h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>        
    </nav>

    <?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM results WHERE result_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);
    $result = $stmt->fetch();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $race_id = $_POST['race_id'];
        $participant_id = $_POST['participant_id'];
        $finish_time = $_POST['finish_time'];
        $position = $_POST['position'];

        $query = "UPDATE results SET race_id = ?, participant_id = ?, finish_time = ?, position = ? WHERE result_id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$race_id, $participant_id, $finish_time, $position, $id]);

        header('Location: results.php');
    }
} else {
    echo "Result ID not specified.";
    exit;
}

?>

<h1>Edit Result</h1>
<form method="POST">
    <label for="race_id">Race ID:</label>
    <input type="text" id="race_id" name="race_id" value="<?= htmlspecialchars($result['race_id']) ?>" required>

    <label for="participant_id">Participant ID:</label>
    <input type="text" id="participant_id" name="participant_id" value="<?= htmlspecialchars($result['participant_id']) ?>" required>

    <label for="finish_time">Finish Time:</label>
    <input type="text" id="finish_time" name="finish_time" value="<?= htmlspecialchars($result['finish_time']) ?>" required>

    <label for="position">Position:</label>
    <input type="text" id="position" name="position" value="<?= htmlspecialchars($result['position']) ?>" required>

    <button type="submit">Update</button>
</form>


    <footer>
        <p>&copy; 2024 ARSTN Drag Race . All Rights Reserved.</p>
    </footer>
</body>
</html>
