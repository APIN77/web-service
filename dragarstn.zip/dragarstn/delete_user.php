<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM users WHERE user_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);

    header('Location: users.php');
} else {
    echo "User ID not specified.";
}
?>
