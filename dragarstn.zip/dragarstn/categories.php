<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
    <header>
        <h1>Welcome to the ARSTN Drag Race </h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>        
    </nav>
<body>
<?php
include 'db.php';

$query = "SELECT * FROM categories";
$stmt = $pdo->query($query);
$categories = $stmt->fetchAll();

echo "<h1>Categories</h1>";
echo "<a href='create_category.php'>Add New Category</a>";
echo "<table>";
echo "<tr><th>ID</th><th>Name</th><th>Description</th><th>Actions</th></tr>";

foreach ($categories as $category) {
    echo "<tr>
            <td>{$category['category_id']}</td>
            <td>{$category['name']}</td>
            <td>{$category['description']}</td>
            <td><a href='edit_category.php?id={$category['category_id']}'>Edit</a> | <a href='delete_category.php?id={$category['category_id']}'>Delete</a></td>
          </tr>";
}
echo "</table>";
?>


    <footer>
        <p>&copy; 2024 ARSTN Drag Race . All Rights Reserved.</p>
    </footer>
</body>
</html>
