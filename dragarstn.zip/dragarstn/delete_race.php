<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM races WHERE race_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);

    header('Location: races.php');
} else {
    echo "Race ID not specified.";
}
?>
