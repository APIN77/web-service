<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
    <header>
        <h1>Welcome to the ARSTN Drag Race </h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>        
    </nav>
<body>
<?php
include 'db.php';

$query = "SELECT * FROM races";
$stmt = $pdo->query($query);
$races = $stmt->fetchAll();

echo "<h1>Races</h1>";
echo "<a href='create_race.php'>Add New Race</a>";
echo "<table>";
echo "<tr><th>ID</th><th>Category ID</th><th>Race Type</th><th>Location</th><th>Date</th><th>Actions</th></tr>";

foreach ($races as $race) {
    echo "<tr>
            <td>{$race['race_id']}</td>
            <td>{$race['category_id']}</td>
            <td>{$race['race_type']}</td>
            <td>{$race['location']}</td>
            <td>{$race['date']}</td>
            <td><a href='edit_race.php?id={$race['race_id']}'>Edit</a> | <a href='delete_race.php?id={$race['race_id']}'>Delete</a></td>
          </tr>";
}
echo "</table>";
?>

    <footer>
        <p>&copy; 2024 ARSTN Drag Race . All Rights Reserved.</p>
    </footer>
</body>
</html>
