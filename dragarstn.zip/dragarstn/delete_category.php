<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM categories WHERE category_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);

    header('Location: categories.php');
} else {
    echo "Category ID not specified.";
}
?>
