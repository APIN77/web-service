<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM results WHERE result_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);

    header('Location: results.php');
} else {
    echo "Result ID not specified.";
}
?>
