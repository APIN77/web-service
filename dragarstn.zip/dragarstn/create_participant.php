<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to the ARSTN Drag Race </h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>        
    </nav>

    <?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $race_id = $_POST['race_id'];
    $user_id = $_POST['user_id'];
    $vehicle_details = $_POST['vehicle_details'];

    $query = "INSERT INTO participants (race_id, user_id, vehicle_details) VALUES (?, ?, ?)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$race_id, $user_id, $vehicle_details]);

    header('Location: participants.php');
}

?>

<h1>Create New Participant</h1>
<form method="POST">
    <label for="race_id">Race ID:</label>
    <input type="text" id="race_id" name="race_id" required>
    
    <label for="user_id">User ID:</label>
    <input type="text" id="user_id" name="user_id" required>

    <label for="vehicle_details">Vehicle Details:</label>
    <input type="text" id="vehicle_details" name="vehicle_details">
    
    <button type="submit">Submit</button>
</form>

    <footer>
        <p>&copy; 2024 ARSTN Drag Race . All Rights Reserved.</p>
    </footer>
</body>
</html>
