<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
    <header>
        <h1>Welcome to the ARSTN Drag Race </h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>        
    </nav>
<body>
<?php
include 'db.php';

$query = "SELECT * FROM participants";
$stmt = $pdo->query($query);
$participants = $stmt->fetchAll();

echo "<h1>Participants</h1>";
echo "<a href='create_participant.php'>Add New Participant</a>";
echo "<table>";
echo "<tr><th>ID</th><th>Race ID</th><th>User ID</th><th>Vehicle Details</th><th>Registration Date</th><th>Actions</th></tr>";

foreach ($participants as $participant) {
    echo "<tr>
            <td>{$participant['participant_id']}</td>
            <td>{$participant['race_id']}</td>
            <td>{$participant['user_id']}</td>
            <td>{$participant['vehicle_details']}</td>
            <td>{$participant['registration_date']}</td>
            <td><a href='edit_participant.php?id={$participant['participant_id']}'>Edit</a> | <a href='delete_participant.php?id={$participant['participant_id']}'>Delete</a></td>
          </tr>";
}
echo "</table>";
?>

    <footer>
        <p>&copy; 2024 Drag Race System. All Rights Reserved.</p>
    </footer>
</body>
</html>
