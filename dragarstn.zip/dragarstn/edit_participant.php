<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to the ARSTN Drag Race </h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>        
    </nav>

    <?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM participants WHERE participant_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);
    $participant = $stmt->fetch();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $race_id = $_POST['race_id'];
        $user_id = $_POST['user_id'];
        $vehicle_details = $_POST['vehicle_details'];

        $query = "UPDATE participants SET race_id = ?, user_id = ?, vehicle_details = ? WHERE participant_id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$race_id, $user_id, $vehicle_details, $id]);

        header('Location: participants.php');
    }
} else {
    echo "Participant ID not specified.";
    exit;
}

?>

<h1>Edit Participant</h1>
<form method="POST">
    <label for="race_id">Race ID:</label>
    <input type="text" id="race_id" name="race_id" value="<?= htmlspecialchars($participant['race_id']) ?>" required>
    
    <label for="user_id">User ID:</label>
    <input type="text" id="user_id" name="user_id" value="<?= htmlspecialchars($participant['user_id']) ?>" required>

    <label for="vehicle_details">Vehicle Details:</label>
    <input type="text" id="vehicle_details" name="vehicle_details" value="<?= htmlspecialchars($participant['vehicle_details']) ?>">

    <button type="submit">Update</button>
</form>


    <footer>
        <p>&copy; 2024 ARSTN Drag Race . All Rights Reserved.</p>
    </footer>
</body>
</html>
