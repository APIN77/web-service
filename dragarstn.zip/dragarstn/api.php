<?php

header("Content-Type: application/json");
require 'db.php'; // Ensure this file connects to your database

// Utility function to send a JSON response
function response($status, $data) {
    http_response_code($status);
    echo json_encode($data);
    exit;
}

// Get the request method and parameters
$method = $_SERVER['REQUEST_METHOD'];
$endpoint = $_GET['endpoint'] ?? null;

// Retrieve request data for POST and PUT
$input = json_decode(file_get_contents("php://input"), true);

// Check if the database connection is working
try {
    $pdo = new PDO("mysql:host=localhost;dbname=dragrace", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    response(500, ["error" => "Database connection failed: " . $e->getMessage()]);
}

// CRUD Operations
switch ($endpoint) {
    case 'categories':
    case 'participants':
    case 'races':
    case 'results':
    case 'users':
        handleCRUD($endpoint, $method, $input, $pdo);
        break;

    default:
        response(400, ["error" => "Invalid endpoint"]);
}

function handleCRUD($table, $method, $data, $pdo) {
    switch ($method) {
        case 'GET':
            handleGet($table, $pdo);
            break;
        case 'POST':
            handlePost($table, $data, $pdo);
            break;
        case 'PUT':
            handlePut($table, $data, $pdo);
            break;
        case 'DELETE':
            handleDelete($table, $pdo);
            break;
        default:
            response(405, ["error" => "Method not allowed"]);
    }
}

function handleGet($table, $pdo) {
    $idKey = primaryKey($table);
    $id = $_GET[$idKey] ?? null;

    if ($id) {
        $stmt = $pdo->prepare("SELECT * FROM $table WHERE $idKey = ?");
        $stmt->execute([$id]);
        $record = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($record) {
            response(200, $record);
        } else {
            response(404, ["error" => "$table record not found"]);
        }
    } else {
        $stmt = $pdo->query("SELECT * FROM $table");
        response(200, $stmt->fetchAll(PDO::FETCH_ASSOC));
    }
}

function handlePost($table, $data, $pdo) {
    $columns = array_keys($data);
    $values = array_values($data);

    $placeholders = implode(',', array_fill(0, count($columns), '?'));
    $sql = "INSERT INTO $table (" . implode(',', $columns) . ") VALUES ($placeholders)";

    $stmt = $pdo->prepare($sql);

    if ($stmt->execute($values)) {
        response(201, ["success" => "$table record created"]);
    } else {
        response(400, ["error" => "Failed to create $table record"]);
    }
}

function handlePut($table, $data, $pdo) {
    $idKey = primaryKey($table);
    $id = $_GET[$idKey] ?? null;

    if (!$id) {
        response(400, ["error" => "$idKey is required for update"]);
    }

    $columns = array_keys($data);
    $placeholders = implode(' = ?, ', $columns) . ' = ?';
    $values = array_values($data);
    $values[] = $id;

    $sql = "UPDATE $table SET $placeholders WHERE $idKey = ?";

    $stmt = $pdo->prepare($sql);

    if ($stmt->execute($values)) {
        response(200, ["success" => "$table record updated"]);
    } else {
        response(400, ["error" => "Failed to update $table record"]);
    }
}

function handleDelete($table, $pdo) {
    $idKey = primaryKey($table);
    $id = $_GET[$idKey] ?? null;

    if (!$id) {
        response(400, ["error" => "$idKey is required for deletion"]);
    }

    $sql = "DELETE FROM $table WHERE $idKey = ?";
    $stmt = $pdo->prepare($sql);

    if ($stmt->execute([$id])) {
        response(200, ["success" => "$table record deleted"]);
    } else {
        response(400, ["error" => "Failed to delete $table record"]);
    }
}

function primaryKey($table) {
    $primaryKeys = [
        'categories' => 'category_id',
        'participants' => 'participant_id',
        'races' => 'race_id',
        'results' => 'result_id',
        'users' => 'user_id',
    ];

    return $primaryKeys[$table] ?? 'id';
}
?>
