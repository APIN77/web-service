<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to the ARSTN Drag Race </h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>        
    </nav>

    <?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM categories WHERE category_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);
    $category = $stmt->fetch();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = $_POST['name'];
        $description = $_POST['description'];

        $query = "UPDATE categories SET name = ?, description = ? WHERE category_id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$name, $description, $id]);

        header('Location: categories.php');
    }
} else {
    echo "Category ID not specified.";
    exit;
}

?>

<h1>Edit Category</h1>
<form method="POST">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" value="<?= htmlspecialchars($category['name']) ?>" required>
    <label for="description">Description:</label>
    <textarea id="description" name="description"><?= htmlspecialchars($category['description']) ?></textarea>
    <button type="submit">Update</button>
</form>


    <footer>
        <p>&copy; 2024 ARSTN Drag Race . All Rights Reserved.</p>
    </footer>
</body>
</html>
