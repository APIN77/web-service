<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
    <header>
        <h1>Welcome to the ARSTN Drag Race </h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>        
    </nav>
<body>
<?php
include 'db.php';

$query = "SELECT * FROM users";
$stmt = $pdo->query($query);
$users = $stmt->fetchAll();

echo "<h1>Users</h1>";
echo "<a href='create_user.php'>Add New User</a>";
echo "<table>";
echo "<tr><th>ID</th><th>Username</th><th>Nama Team</th><th>Created At</th><th>Actions</th></tr>";

foreach ($users as $user) {
    echo "<tr>
            <td>{$user['user_id']}</td>
            <td>{$user['username']}</td>
            <td>{$user['team_name']}</td>
            <td>{$user['created_at']}</td>
            <td><a href='edit_user.php?id={$user['user_id']}'>Edit</a> | <a href='delete_user.php?id={$user['user_id']}'>Delete</a></td>
          </tr>";
}
echo "</table>";
?>

    <footer>
        <p>&copy; 2024 ARSTN Drag Race . All Rights Reserved.</p>
    </footer>
</body>
</html>
