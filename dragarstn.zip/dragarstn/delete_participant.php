<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM participants WHERE participant_id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);

    header('Location: participants.php');
} else {
    echo "Participant ID not specified.";
}
?>
