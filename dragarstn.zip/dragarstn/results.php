<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drag Race System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to the ARSTN Drag Race</h1>
    </header>

    <nav>
        <a href="users.php">Users</a>
        <a href="index.php">Home</a>
        <a href="categories.php">Categories</a>
        <a href="races.php">Races</a>
        <a href="participants.php">Participants</a>
        <a href="results.php">Results</a>       
    </nav>

    <div class="content">
        <?php
        include 'db.php';

        // Query untuk mengambil hasil lomba, diurutkan berdasarkan finish_time
        $query = "SELECT r.result_id, r.race_id, r.participant_id, r.finish_time, r.position, p.vehicle_details, ra.date AS race_date, ra.race_type 
                  FROM results r
                  JOIN participants p ON r.participant_id = p.participant_id
                  JOIN races ra ON r.race_id = ra.race_id
                  ORDER BY ra.race_type, r.finish_time ASC";
        $stmt = $pdo->query($query);
        $results = $stmt->fetchAll();

        // Mengelompokkan hasil berdasarkan race_type
        $groupedResults = [
            '201m' => [],
            '402m' => [],
            '1000m' => []
        ];

        foreach ($results as $result) {
            $groupedResults[$result['race_type']][] = $result;
        }

        // Menampilkan tabel untuk setiap jenis track
        foreach ($groupedResults as $raceType => $raceResults) {
            echo "<h2>Track: {$raceType}</h2>";
            echo "<a href='create_result.php'>Add New Result</a>";
            echo "<table border='1'>";
            echo "<tr>
                    <th>Race ID</th>
                    <th>Participant ID</th>
                    <th>Vehicle Details</th>
                    <th>Finish Time</th>
                    <th>Position</th>
                    <th>Race Date</th>
                    <th>Actions</th>
                  </tr>";

            foreach ($raceResults as $result) {
                echo "<tr>
                        <td>{$result['race_id']}</td>
                        <td>{$result['participant_id']}</td>
                        <td>{$result['vehicle_details']}</td>
                        <td>{$result['finish_time']}</td>
                        <td>{$result['position']}</td>
                        <td>{$result['race_date']}</td>
                        <td><a href='edit_result.php?id={$result['result_id']}'>Edit</a> | <a href='delete_result.php?id={$result['result_id']}'>Delete</a></td>
                      </tr>";
            }
            echo "</table>";
        }
        ?>
    </div>

    <footer>
        <p>&copy; 2024 ARSTN Drag Race. All Rights Reserved.</p>
    </footer>
</body>
</html>
